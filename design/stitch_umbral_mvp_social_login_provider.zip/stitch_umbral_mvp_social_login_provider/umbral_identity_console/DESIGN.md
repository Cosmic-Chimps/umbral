---
name: Umbral Identity Console
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#c7c4d8'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#918fa1'
  outline-variant: '#464555'
  surface-tint: '#c3c0ff'
  primary: '#c3c0ff'
  on-primary: '#1d00a5'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#4d44e3'
  secondary: '#bdc2ff'
  on-secondary: '#131e8c'
  secondary-container: '#2f3aa3'
  on-secondary-container: '#a8afff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e0e0ff'
  secondary-fixed-dim: '#bdc2ff'
  on-secondary-fixed: '#000767'
  on-secondary-fixed-variant: '#2f3aa3'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.375rem
    letterSpacing: '0'
  body-lg:
    fontFamily: Space Mono
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Space Mono
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Space Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Space Mono
    fontSize: 0.8125rem
    fontWeight: '700'
    lineHeight: 1.125rem
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Mono
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 1rem
    letterSpacing: 0.08em
  code-telemetry:
    fontFamily: Space Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: '0'
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies an uncompromising, industrial brutalist infrastructure console engineered specifically for self-hosted authentication, access control, and edge federation. It discards decorative ornamentation in favor of high-density telemetry, structural precision, and architectural transparency.

The target audience consists of homelab operators, systems engineers, and self-hosters running zero-trust networks, container clusters, and federated identity topologies. The interface must evoke total sovereignty, cryptographic reliability, and immediate situational awareness. 

The aesthetic is characterized by:
- Pure orthogonal layouts with strict zero-radius terminations.
- High-contrast, monospaced diagnostic readouts alongside stark geometric headings.
- Visible mechanical structure: continuous 1px perimeter grids, modular chassis panels, and visible system status flags.
- Functional austerity: every visual element corresponds strictly to cryptographic state, network egress, protocol health, or credential delegation.

## Colors

The color palette is built on deep obsidian voids intersected by vivid electromagnetic accents. The background establishes a cold, lightless canvas that maximizes legibility for long monitoring sessions and continuous console operation.

### Token Semantic Mapping
- **Primary (`#4F46E5`)**: Signals active protocol routines, primary identity actions, token verification triggers, and authoritative infrastructure commands.
- **Secondary (`#818CF8`)**: Used for secondary diagnostic states, focused border highlights, active payload keys, and selected scopes.
- **Tertiary / Active Emerald (`#10B981`)**: Explicit operational health, verified cryptographic claims, valid JSON Web Keys (JWKS), and active TLS sessions.
- **Warning Amber (`#F59E0B`)**: Unverified client redirects, self-signed or expiring certificates, and unvalidated identity provider assertions.
- **Destructive Rose (`#F43F5E`)**: Revocation of refresh tokens, client secret deprecation, session invalidation, and killswitch triggers.
- **Neutral Canvas (`#090D16`)**: Ground-zero chassis background.
- **Neutral Surface Elevated (`#0F172A`)**: Enclosure containers, tabular rows, and telemetry viewports.
- **Neutral Surface Border (`#1E293B`)**: Rigid 1px boundary dividers demarcating data fields and structural splits.

## Typography

The typography establishes a strict division of labor between architectural hierarchy and operational data:

- **Headlines (`Space Grotesk`)**: Provide assertive, geometric authority for zone titles, service scopes, and modal titles. Character tracking is tightened slightly to convey mechanical density and structure.
- **Body & Labels (`Space Mono`)**: Unconditionally utilized for all interface strings, cryptographic tokens, OIDC discovery URLs (`/.well-known/openid-configuration`), Client IDs, SHA-256 fingerprints, and redirect patterns.
- **Casing & Weight**: Metadata labels, field headers, and status flags are styled in uppercase with expanded letter-spacing to mirror physical terminal readouts and military-grade hardware labeling.

## Layout & Spacing

The layout is grounded in a high-density, modular fluid-grid architecture adapted for hardware dashboards and mobile terminal monitoring.

### Structure & Rhythm
- **Rhythm Unit**: Strict 4px/8px incremental base rhythm. Vertical layout boundaries lock to 1rem (16px) multiples.
- **Mobile Grid (up to 767px)**: Single-column full-width chassis layout with `margin: 1rem`. Controls stack vertically into dense horizontal bands. High-priority cryptographic states anchor at the top edge.
- **Tablet Grid (768px - 1023px)**: 6-column fluid structure with `margin-tablet: 1.5rem` and `gutter: 1rem`. OIDC clients and user scopes adapt to a two-column balance.
- **Desktop Grid (1024px+)**: 12-column architectural matrix with `margin-desktop: 2rem` and `gutter-desktop: 1.5rem`. Split-pane layout: permanent left telemetry/client selector panel (3 cols), primary operational configuration workspace (6 cols), and real-time JWT inspector/event stream monitor (3 cols).

## Elevation & Depth

This design system avoids physical drop shadows, blur passes, and skeuomorphic lighting models. Elevation is communicated entirely through **tonal stratification** and **mechanical structural containment**:

1. **Chassis Bed (`#090D16`)**: The deepest canvas level, representing host OS infrastructure.
2. **Modular Frame (`#0F172A`)**: Component panels, client cards, and credential stores sit flat atop the canvas, segmented by explicit 1px borders (`#1E293B`).
3. **Active/Interactive Surface (`#141E33`)**: Input wells, code displays, and pressed states recess inward using a darker fill with sharp high-contrast border definition.
4. **Transient Overlays & Flyouts**: When prompt dialogs, secret reveals, or context actions appear, they deploy with a pure opaque background (`#0F172A`), zero backdrop blur, an impenetrable solid border (`#4F46E5`), and a sharp 2px solid offset border shadow (`#000000`) with no diffusion.

## Shapes

The geometric directive is uncompromising: **Absolute zero radius across all elements**.

Every button, card, input field, status badge, toggle, and dialog terminates in precise, razor-sharp 90-degree right angles. This geometry reinforces the brutalist developer-tool ethos, optimizing spatial packing down to the single pixel and mirroring hardware rack-mounted monitors, terminal emulators, and hard-edged network appliances.

## Components

### Buttons
- **Primary**: Solid background `#4F46E5`, text `#FFFFFF`, zero radius, 1px solid `#818CF8`. Hover shifts background to `#4338CA`. Active state shifts border to 2px solid `#FFFFFF`.
- **Secondary / Neutral**: Background transparent, text `#818CF8`, 1px solid `#1E293B`. Hover introduces `#0F172A` background and `#818CF8` border.
- **Destructive**: Background `#0F172A`, text `#F43F5E`, 1px solid `#F43F5E`. On hover, fills solid `#F43F5E` with `#FFFFFF` text.
- **Action Padding**: `0.5rem 1rem` for standard targets; `0.25rem 0.625rem` for compact telemetry buttons.

### Status Indicators & Badges
- Strictly rectangular monospace badges. No pill shapes.
- 1px hairline border with matching 10% opacity background fill:
  - *Active / Healthy*: Border `#10B981`, fill `rgba(16, 185, 129, 0.1)`, text `#10B981`. Includes a leading solid square dot `■`.
  - *Warning / Unverified*: Border `#F59E0B`, fill `rgba(245, 158, 11, 0.1)`, text `#F59E0B`.
  - *Revoked / Inactive*: Border `#F43F5E`, fill `rgba(244, 63, 94, 0.1)`, text `#F43F5E`.

### Telemetry Copy Fields (Client IDs, Secrets, URIs)
- Composed as segmented inline terminal blocks.
- Background `#05080E`, border 1px solid `#1E293B`, text `#818CF8` in `Space Mono`.
- Built-in trailing action cell housing a rigid square `[COPY]` trigger. Upon successful copy, the cell pulses solid `#10B981` with text invert for 800ms.

### Toggle Switches (Binary Feature Flags)
- Square dual-state switches. Zero rounding.
- Enclosure: 40px width × 20px height, background `#090D16`, border 1px solid `#1E293B`.
- Thumb: 16px × 16px sharp block, positioned flush. Inactive state: `#475569`. Active state: `#10B981` with enclosure border switching to `#10B981`.

### Input Fields & Textareas
- Background `#090D16`, border 1px solid `#1E293B`, text `#FFFFFF`, caret `#818CF8`.
- Focus state: Border shifts to `#4F46E5` with a continuous 1px outline ring without corner softening.
- Helper labels and validation messages render strictly beneath inputs in uppercase `label-sm`.

### Client Cards & Panels
- Background `#0F172A`, 1px solid `#1E293B`.
- Header bar features a mechanical metadata bar with timestamp, protocol indicators (`OIDC 1.0`, `OAuth 2.1`), and current token signing algorithm (`RS256`, `EdDSA`).
- Hover state transitions top border to `#4F46E5`.

### Real-Time Event Log & JWT Inspector
- Monospaced stream with alternating subtle row fills (`#0F172A` / `#0B1120`).
- Color-coded JSON payload highlighting: keys in `#818CF8`, strings in `#10B981`, timestamps and scopes in `#F59E0B`.